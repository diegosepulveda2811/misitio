document.addEventListener('DOMContentLoaded', () => {

  // Página 1 -> Navegación a Página 2
  const btnReportar = document.getElementById('btn-reportar');
  if (btnReportar) {
    btnReportar.addEventListener('click', () => {
      window.location.href = 'categoria.html';
    });
  }

  // Página 2 -> Navegación hacia atrás o Selección de Categoria
  const btnBack = document.getElementById('btn-back');
  if (btnBack) {
    btnBack.addEventListener('click', () => {
      window.location.href = 'index.html';
    });
  }

  const optionCards = document.querySelectorAll('.option-card');
  optionCards.forEach(card => {
    card.addEventListener('click', () => {
      // Seleccionar opción y navegar a la confirmación
      window.location.href = 'confirmacion.html';
    });
  });

  // Página 3 -> Volver al inicio
  const btnInicio = document.getElementById('btn-inicio');
  if (btnInicio) {
    btnInicio.addEventListener('click', () => {
      window.location.href = 'index.html';
    });
  }

});